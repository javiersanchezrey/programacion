package Examen;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ejercicio3 {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("¿Podrías escribir cuál es el nombre del concursante?");
	String nombreConcursante = br.readLine();
	
		System.out.println("¿Fué el favorito de la semana?");
	char favorito = br.readLine().toLowerCase().charAt(0);
	
		System.out.println("¿Cuál fué su porcentaje de voto de esta semana?");
	double porcentajeVoto = Double.parseDouble(br.readLine());
	
		System.out.println("¿El concursante elegido a cantado en un dúo previamente?");
	char duo = br.readLine().toLowerCase().charAt(0);
		
		if (favorito == 's' || porcentajeVoto >= 80) {
			System.out.println("El concursante " + nombreConcursante + " cantará en solitario esta semana.");
			
		} else if (favorito == 'n' && porcentajeVoto < 60 && duo == 's' ){
			System.out.println("El concursante " + nombreConcursante + " cantará en grupo esta semana.");
			
		}else if (porcentajeVoto < 60 || duo == 'n') {
			System.out.println("El concursante " + nombreConcursante + " cantará en dúo esta semana.");
		}
			
	}

}
